import express from 'express';
import dotenv from 'dotenv';

import logger from '#configs/logger.js';
import { logRequest, logError } from '#middlewares/logger.middleware.js';
import { headerMiddleware } from '#middlewares/header.middleware.js';
import { errorHandler } from '#middlewares/error.middleware.js';
import userRoutes from '#entities/users/users.route.js';
import { setAllStatics } from './utils/index.js';

// Load environment variables
dotenv.config();

const app = express();

// Disable x-powered-by header for security
app.disable('x-powered-by');

// ============================================
// MIDDLEWARES
// ============================================

// Body parsing
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Logging middleware (before routes)
app.use(logRequest);

// Custom headers
app.use(headerMiddleware);

// Static files
setAllStatics(app);

// Swagger docs (commented out)
// app.use('/api-docs', ...swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// ============================================
// ROUTES
// ============================================

// Health check endpoint
app.get('/health', (req, res) => {
  logger.app.info('Health check requested', {
    ip: req.ip,
    userAgent: req.headers['user-agent'],
  });
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// API routes
app.use('/api', userRoutes);

// 404 handler
app.use((req, res, next) => {
  const error = new Error(`Route not found: ${req.method} ${req.url}`);
  error.statusCode = 404;
  error.code = 'ROUTE_NOT_FOUND';
  next(error);
});

// Error handling middleware (should be last)
app.use(logError);
app.use(errorHandler);

export default app;
