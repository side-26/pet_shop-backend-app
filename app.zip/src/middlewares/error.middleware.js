import { STATUES } from '#configs/constants.js';
import logger from '#configs/logger.js';

export const errorHandler = (err, req, res, next) => {
  void next;

  const statusCode = err?.statusCode || STATUES.INTERNAL_SERVER;

  // Only log if not already logged
  if (!err._logged) {
    if (statusCode >= 400 && statusCode < 500) {
      logger.warn({
        type: 'ERROR_HANDLER',
        statusCode,
        message: err?.message,
        code: err?.code,
        requestId: req?.id,
        timestamp: new Date().toISOString(),
      });
    } else {
      logger.error({
        type: 'ERROR_HANDLER',
        statusCode,
        error: {
          message: err?.message,
          stack: process.env.NODE_ENV === 'production' ? undefined : err?.stack,
          name: err?.name,
          code: err?.code,
        },
        requestId: req?.id,
        timestamp: new Date().toISOString(),
      });
    }
    err._logged = true;
  }

  // Send response with request ID
  res.status(statusCode).json({
    isSuccess: false,
    message: err?.message || 'خطای سمت سرور',
    data: {
      messages: err?.data?.messages || null,
      detail: err?.data?.detail || null,
    },
    requestId: req?.id,
    timestamp: new Date().toISOString(),
  });
};
