export const ROUTES = {
  users: {
    getAll: '/users/all',
    getAllPaginate: '/users/paginate',
    getUserById: '/users/:id',
    getUserCart: '/users/cart/:id',
    createUser: '/users',
    updateUserInfo: '/users/editInfo',
    updateUserLocationInfo: '/users/editLocationInfo',
    deleteUser: '/users/delete/:id',
    disableUser: '/users/disable/:id',
    enableUser: '/users/enable/:id',
    login: '/users/login',
    register: '/users/register',
    changePassword: '/users/changePassword',
    userCart: '/users/profile/cart',
  },
  profile: {
    login: '/profile/login',
    updateProfile: '/profile/update',
    changeProfilePassword: '/profile/changePassword',
    getProfileIdentity: '/profile/identity',
  },
  orders: {
    getAll: '/orders/all',
    getAllPaginate: '/orders/paginate',
    getOrderById: '/orders/:id',
    getOrderByUser: '/orders/:userId',
    createOrder: '/orders',
    updateOrder: '/orders/edit/:id',
    deleteOrder: '/orders/delete/:id',
  },
  products: {
    getAll: '/products/all',
    getAllPaginate: '/products/paginate',
    getOrderById: '/products/:id',
    getOrderByUser: '/products/:userId',
    createOrder: '/products',
    updateOrder: '/products/edit/:id',
    deleteOrder: '/products/delete/:id',
  },
};
export const STATUES = {
  SUCCESS: 200,
  CREATED: 201,
  NO_RESPONSE: 204,
  MULTIPLE_CHOICES: 300,
  REDIRECT: 301,
  BAD_REQUEST: 400,
  UN_AUTHORIZED: 401,
  PAYMENT_ERROR: 402,
  NO_ACCESS: 403,
  NOT_FOUND: 404,
  METHOD_NOT_ALLOWED: 405,
  BAD_FORM_VALIDATION: 422,
  INTERNAL_SERVER: 500,
  OTHER_PROBLEM: 503,
};

export const METHODS = {
  // get: 'GET',
  post: 'POST',
  // Put: 'PUT',
  // patch: 'PATCH',
  // delete: 'DELETE',
};

export const ROLES = {
  ADMIN: 'admin',
  CUSTOMER: 'customer',
  SELLER: 'seller',
};
